﻿using Application.DTOs;
using Application.Use_Cases.Commands;
using AutoMapper;
using Domain.Repositories;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Use_Cases.ComandHandlers
{
    public class UpdateBookCommandHandler : IRequestHandler<UpdateBookCommand, BookDto>
    {

        private readonly IBookRepository repository;
        private readonly IMapper mapper;

        public UpdateBookCommandHandler(IBookRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }
        public async Task<BookDto> Handle(UpdateBookCommand request, CancellationToken cancellationToken)
        {
            var book = await repository.GetByIdAsync(request.Id);

            book.Title = request.Title;
            book.PublicationDate = request.PublicationDate;
            book.Author = request.Author;
            book.ISBN = request.ISBN;

            await repository.UpdateAsync(book);

            return mapper.Map<BookDto>(book);
        }
    }
}
